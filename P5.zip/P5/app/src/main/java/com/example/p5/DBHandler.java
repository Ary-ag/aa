package com.example.p5;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

class DbHandler extends SQLiteOpenHelper {

    private static final int db_version=1;
    private static final String db_name="users", table_name="user", user_id="id", user_name="name", user_password="password";


    public DbHandler(MainActivity context) {
        super(context,db_name,null, db_version);
    }

    public void onCreate(SQLiteDatabase db) {
        String Create_Table = "CREATE TABLE " + table_name + " ("
                + user_id + " INTEGER PRIMARY KEY, "
                + user_name + " TEXT, "
                + user_password + " TEXT)";
        db.execSQL(Create_Table);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + table_name);
        onCreate(db);

    }


    public void addUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(user_name, user.getName());
        cv.put(user_password, user.getPassword());
        db.insert(table_name, null, cv);
        db.close();
    }

    public int checkUser(User user) {
        int id = -1;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT id FROM user WHERE name=? AND password=?", new String[]{
                user.getName(), user.getPassword()
        });
        if (cursor.getCount()>0){
            cursor.moveToFirst();
            id=cursor.getInt(0);
            cursor.close();
        }
        return id;
    }
}